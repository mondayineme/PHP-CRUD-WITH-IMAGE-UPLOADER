# php-crud-with-image-upload
PHP CRUD

Create Database on your locahost server
DB = crud
Table Name = contacts
